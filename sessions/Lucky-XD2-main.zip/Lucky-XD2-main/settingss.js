
module.exports = {
  SESSION_ID: "",  // add your Session Id here
  OWNER_NUMBER: "201101260245", // put your phone number here
  PREFIX: ".", // prefix (e.g., ., /, !, *)
  TIMEZONE: "Africa/sudan" //put your country timeZone....leave blank if u don't know.
};
